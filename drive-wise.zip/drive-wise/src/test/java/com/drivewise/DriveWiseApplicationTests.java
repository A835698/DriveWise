package com.drivewise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DriveWiseApplicationTests {

	@Test
	void contextLoads() {
	}

}
