package com.drivewise;

import java.io.File;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.drivewise.utils.DriveWiseUtils;

import jakarta.annotation.PostConstruct;

@SpringBootApplication
public class DriveWiseApplication {

	public static void main(String[] args) {
		SpringApplication.run(DriveWiseApplication.class, args);
	}

	@PostConstruct
	public void initWorks() {
		File directory = new File(DriveWiseUtils.UPLOAD_DIR);
		if (!directory.exists()) {
			directory.mkdirs(); // Create the directory if it doesn't exist
		}
	}
	
}
