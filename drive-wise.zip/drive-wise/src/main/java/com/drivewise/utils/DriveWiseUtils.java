package com.drivewise.utils;

public class DriveWiseUtils {
	
	public static final String MODEL = "gpt-4o-mini-2024-07-18";
	
	// Directory to store the uploaded files
	public static final String UPLOAD_DIR = System.getProperty("java.io.tmpdir") + "/tempUploads/";

}
