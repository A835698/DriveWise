package com.drivewise.controller;

import java.io.File;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.util.Map;

import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.prompt.ChatOptions;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.model.Media;
import org.springframework.ai.openai.OpenAiChatOptions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.util.MimeTypeUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.drivewise.utils.DriveWiseUtils;

@RestController
public class DriveWiseApiController {

	@Autowired
	ChatModel chatModel;

	@PostMapping("/upload")
	public Map<String, String> uploadFile(@RequestParam("file") MultipartFile file) {
		if (file.isEmpty()) {
			return Map.of("response", "Please select a file to upload.");
		}
		try {

			File tempFile = File.createTempFile("temp", ".png", new File(DriveWiseUtils.UPLOAD_DIR));

			// Write the uploaded file's content to the temporary file
			Files.write(tempFile.toPath(), file.getBytes());

			Resource image = new FileSystemResource(tempFile);

			var userMessage = new UserMessage("give me only car no displayed in number plate",
					new Media(MimeTypeUtils.IMAGE_PNG, image));

			String res = chatModel.call(new Prompt(userMessage, getTextModelOptions())).getResults().get(0).getOutput()
					.getContent();

			// String res = "test";

			return Map.of("response", res + " voilated traffic rules hence fine imposed of 500$");

		} catch (Exception e) {
			e.printStackTrace();
			return Map.of("reponse", "Could not upload the file.");
		}
	}

	private ChatOptions getTextModelOptions() {
		ChatOptions options = OpenAiChatOptions.builder().model(DriveWiseUtils.MODEL).build();
		return options;
	}

}
